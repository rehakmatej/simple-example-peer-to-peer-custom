/********************************************************************
 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the "Company") for its PIC(R) Microcontroller is intended and
 supplied to you, the Company's customer, for use solely and
 exclusively on Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *******************************************************************/

#include "system.h"
#include "system_config.h"
#include "console.h"
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <plib.h>
#include <peripheral/int.h>
#include <peripheral/int_5xx_6xx_7xx.h>


// Config Bit Settings to get 16 MHz: Internal 8 MHz / 2 = 4 * 12 = 48 / 3 = 16
// PIC32MX795F512H Configuration Bit Settings

// 'C' source line config statements

// DEVCFG3
// USERID = No Setting

#pragma config FSRSSEL = PRIORITY_7     // SRS Select (SRS Priority 7)
#pragma config FMIIEN = ON              // Ethernet RMII/MII Enable (MII Enabled)
#pragma config FETHIO = ON              // Ethernet I/O Pin Select (Default Ethernet I/O)
#pragma config FCANIO = ON              // CAN I/O Pin Select (Default CAN I/O)
#pragma config FUSBIDIO = OFF           // USB USID Selection (Controlled by Port Function)
#pragma config FVBUSONIO = OFF          // USB VBUS ON Selection (Controlled by Port Function)

// DEVCFG2
#pragma config FPLLIDIV = DIV_2         // PLL Input Divider (2x Divider)
#pragma config FPLLMUL = MUL_20         // PLL Multiplier (15x Multiplier)
#pragma config UPLLIDIV = DIV_4        // USB PLL Input Divider (12x Divider)
#pragma config UPLLEN = OFF             // USB PLL Enable (Disabled and Bypassed)
#pragma config FPLLODIV = DIV_16         // System PLL Output Clock Divider (PLL Divide by 16)

// DEVCFG1
#pragma config FNOSC = PRIPLL           // Oscillator Selection Bits (Primary Osc w/PLL (XT+,HS+,EC+PLL))
#pragma config FSOSCEN = OFF            // Secondary Oscillator Enable (Disabled)
#pragma config IESO = ON                // Internal/External Switch Over (Enabled)
#pragma config POSCMOD = HS             // Primary Oscillator Configuration (HS osc mode)
#pragma config OSCIOFNC = ON            // CLKO Output Signal Active on the OSCO Pin (Enabled)
#pragma config FPBDIV = DIV_1           // Peripheral Clock Divisor (Pb_Clk is Sys_Clk/8)
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor Selection (Clock Switch Disable, FSCM Disabled)
#pragma config WDTPS = PS1048576        // Watchdog Timer Postscaler (1:1048576)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT Disabled (SWDTEN Bit Controls))

// DEVCFG0
#pragma config DEBUG = OFF              // Background Debugger Enable (Debugger is disabled)
#pragma config ICESEL = ICS_PGx1        // ICE/ICD Comm Channel Select (ICE EMUC1/EMUD1 pins shared with PGC1/PGD1)
#pragma config PWP = OFF                // Program Flash Write Protect (Disable)
#pragma config BWP = OFF                // Boot Flash Write Protect bit (Protection Disabled)
#pragma config CP = OFF                 // Code Protect (Protection Disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


/*********************************************************************
 * Function:        void BoardInit( void )
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    Board is initialized for P2P usage
 *
 * Overview:        This function configures the board 
 *
 * Note:            This routine needs to be called before the function 
 *                  to initialize stack or any other function that
 *                  operates on the stack
 ********************************************************************/
void SYSTEM_Initialize(void)
{
    SYSTEMConfig(SYS_CLK_FrequencySystemGet(), SYS_CFG_WAIT_STATES | SYS_CFG_PCACHE);
    /*******************************************************************/
    // Primary Internal Oscillator
    /*******************************************************************/


    /*******************************************************************/
    // Configure PPS Related Pins
    /*******************************************************************/
    // Unlock to config PPS
    

    /*******************************************************************/
    // AN0 & AN1 Analog Pins others Digital Pins
    /*******************************************************************/
    AD1CON1bits.ON = 0;
    AD1CON2bits.CSCNA = 0;
    /*******************************************************************/
    // Configure Switch and LED I/O Ports
    /*******************************************************************/
    LED_0 = 0;
    LED_1 = 0;
    LED_2 = 0;
    LED0_TRIS = 0;
    LED1_TRIS = 0;
    LED2_TRIS = 0;
            
    BUTTON_1_TRIS = 1;
    BUTTON_2_TRIS = 1;      
								
    //INTCON2bits.RBPU = 0;   // Enable PORTB Pull-ups for Switches

    /*******************************************************************/
    // Configure the Temp Sensor and VBat port
    /*******************************************************************/	
    //TRISAbits.TRISA1 = 1;
    //TRISAbits.TRISA0 = 1;
    
    /*******************************************************************/
    // Config RF Radio
    /*******************************************************************/
    /*******************************************************************/
    // Config MRF24J40 Pins
    /*******************************************************************/
    PHY_CS = 1;
    PHY_RESETn = 1;    
    PHY_WAKE = 1;
    
    PHY_CS_TRIS = 0;
    PHY_RESETn_TRIS = 0;        
    PHY_WAKE_TRIS = 0;
    RF_INT_TRIS = 1;
             
    // Config INT0 Edge = Falling
    //INTCON2bits.INTEDG0 = 0;
    INTConfigureSystem(INT_SYSTEM_CONFIG_MULT_VECTOR);
    INTEnableInterrupts();
    INTClearFlag(INT_INT0);
    ConfigINT0(FALLING_EDGE_INT | EXT_INT_ENABLE);
    IPC0SET = 0x04000000;
    INTEnable(INT_INT0, INT_ENABLED);
    
    //RFIF = 0;
    //RFIE = 1;
    
    /*******************************************************************/
    // Confiure SPI1
    /*******************************************************************/     
    SDI_TRIS = 1;
    SDO_TRIS = 0;
    SCK_TRIS = 0;
    
    //SSP1STAT = 0xC0;
    //SSP1CON1 = 0x20;
    
    SPI2CONbits.SMP = 1;
    SPI2CONbits.CKE = 1;
   

    
    /*******************************************************************/    
    // Configure EEProm Pins
    /*******************************************************************/
    RF_EEnCS = 1;
    RF_EEnCS_TRIS = 0;
    EE_nCS = 1;
    EE_nCS_TRIS = 0;

    
    /*******************************************************************/
    // Configure LCD Pins
    /*******************************************************************/
    /*LCD_BKLT = 0;
    LCD_CS = 1;
    LCD_RS = 0;
    LCD_RESET = 0;
    LCD_BKLT_TRIS = 0;
    LCD_CS_TRIS = 0;
    LCD_RS_TRIS = 0;
    LCD_RESET_TRIS = 0;*/

    
    /*******************************************************************/
    // Configure SPI2
    /*******************************************************************/   
    SDI2_TRIS = 1;
    SDO2_TRIS = 0;
    SCK2_TRIS = 0;
    
    SPI3STAT = 0x00;
    //SSP2CON1 = 0x31;
    SPI3CONbits.ON = 1;
    SPI3CONbits.CKP = 1;
    
    IFS0bits.SPI3RXIF = 0;
    IFS0bits.SPI3TXIF = 0;
    

    //LCD_Initialize();
    CONSOLE_Initialize();
    /*******************************************************************/
    // Enable System Interupts
    /*******************************************************************/
    //INTCONbits.GIEH = 1;
    //INTCONbits.GIEL = 1;
    SPI2CONbits.FRMEN = 0;
    SPI2CONbits.FRMSYNC = 0;
    SPI2CONbits.FRMPOL = 0;
    SPI2CONbits.MSSEN = 0;
    SPI2CONbits.FRMSYPW = 0;
    SPI2CONbits.ENHBUF = 0;
    SPI2CONbits.ON = 1;
    SPI2CONbits.SIDL = 0;
    SPI2CONbits.DISSDO = 0;
    SPI2CONbits.SMP = 0;
    SPI2CONbits.CKE = 1;
    SPI2CONbits.CKP = 0;
    SPI2CONbits.SSEN = 0;
    SPI2CONbits.MSTEN = 1;
    SPI2BRG = 0;
    //INTEnableSystemMultiVectoredInt();
    //INTEnableInterrupts();
    RF_INT_TRIS = 1;
    /*ConfigINT0(FALLING_EDGE_INT);
    INTSetVectorPriority(INT_VECTOR_EX_INT(INT_INT0),INT_PRIORITY_LEVEL_6);
    INTClearFlag(INT_SOURCE_EX_INT(INT_INT0));
    INTEnable(INT_SOURCE_EX_INT(INT_INT0),INT_ENABLED);
    INTClearFlag(INT_SOURCE_EX_INT(INT_INT0));*/
    LED_0 = 1;
    LED_1 = 1;
    
}


