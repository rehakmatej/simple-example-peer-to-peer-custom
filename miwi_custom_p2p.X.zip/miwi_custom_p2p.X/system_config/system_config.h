/********************************************************************
 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the "Company") for its PIC(R) Microcontroller is intended and
 supplied to you, the Company's customer, for use solely and
 exclusively on Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *******************************************************************/

#ifndef _SYSTEM_CONFIG_H
#define _SYSTEM_CONFIG_H
 
#include "miwi_config.h"        //Include miwi application layer configuration file
#include "miwi_config_p2p.h"   //Include protocol layer configuration file
#include "config_24j40.h"       //Transceiver configuration file
 
#define SW1             1
#define SW2             2	
    
// There are three ways to use NVM to store data: External EPROM, Data EEPROM and
// programming space, with following definitions:
//      #define USE_EXTERNAL_EEPROM
//      #define USE_DATA_EEPROM
//      #define USE_PROGRAMMING_SPACE
// Each demo board has defined the method of using NVM, as
// required by Network Freezer feature.
#define USE_EXTERNAL_EEPROM

#define SUPPORT_TWO_SPI

// Define EEPROM_SHARE_SPI if external EEPROM shares the SPI
// bus with RF transceiver
//#define EEPROM_SHARE_SPI

// MRF24J40 Pin Definitions
#define RFIF                IFS0bits.INT0IF
#define RFIE                IEC0bits.INT0IE
#define PHY_CS              LATEbits.LATE7
#define PHY_CS_TRIS         TRISEbits.TRISE7
#define RF_INT_PIN          PORTDbits.RD0
#define RF_INT_TRIS         TRISDbits.TRISD0
#define PHY_WAKE            LATCbits.LATC13
#define PHY_WAKE_TRIS       TRISCbits.TRISC13
#define PHY_RESETn          LATDbits.LATD10
#define PHY_RESETn_TRIS     TRISDbits.TRISD10


// EEProm Pin Definitions
#define RF_EEnCS            LATDbits.LATD5
#define RF_EEnCS_TRIS	    TRISDbits.TRISD5

// SPI1 Pin Definitions
#define SPI_SDI             PORTGbits.RG7
#define SDI_TRIS            TRISGbits.TRISG7
#define SPI_SDO             LATGbits.LATG8
#define SDO_TRIS            TRISGbits.TRISG8
#define SPI_SCK             LATGbits.LATG6
#define SCK_TRIS            TRISGbits.TRISG6

// SPI2 Pin Definitions
#define SPI_SDI2            PORTDbits.RD2
#define SDI2_TRIS           TRISDbits.TRISD2
#define SPI_SDO2            LATDbits.LATD3
#define SDO2_TRIS           TRISDbits.TRISD3
#define SPI_SCK2            LATDbits.LATD1
#define SCK2_TRIS           TRISDbits.TRISD1

#define SPI2SSPIF           IFS0bits.SPI3RXIF
#define SPI2WCOL            SSP2CON1bits.WCOL
#define SPI2SSPBUF          SPI3BUF

// Switch and LED Pin Definitions
#define PUSH_BUTTON_1            PORTGbits.RG2
#define BUTTON_1_TRIS            TRISGbits.TRISG2
#define PUSH_BUTTON_2            PORTGbits.RG3
#define BUTTON_2_TRIS            TRISGbits.TRISG3

#define LED_0                LATBbits.LATB8
#define LED0_TRIS           TRISBbits.TRISB8
#define LED_1                LATBbits.LATB9
#define LED1_TRIS           TRISBbits.TRISB9
#define LED_2                LATBbits.LATB15
#define LED2_TRIS           TRISBbits.TRISB15

// External EEPROM Pin Definitions
//#define EE_nCS_TRIS         TRISDbits.TRISD5
#define MAC_nCS             LATDbits.LATD5
#define TMRL                (char)(TMR2 & 0x00FF)

//External SST Serial Flash Definitions
#define EE_nCS              LATDbits.LATD7
#define EE_nCS_TRIS         TRISDbits.TRISD7

// LCD Pin Definitions
//#define LCD_CS_TRIS         TRISDbits.TRISD7
//#define LCD_CS              LATDbits.LATD7
//#define LCD_RS_TRIS         TRISDbits.TRISD3
//#define LCD_RS              LATDbits.LATD3
//#define LCD_RESET_TRIS      TRISEbits.TRISE0
//#define LCD_RESET           LATEbits.LATE0
//#define LCD_BKLT_TRIS       TRISEbits.TRISE1
//#define LCD_BKLT            LATEbits.LATE1
	
#endif




#include <peripheral/spi.h>
#include <proc/p32mx795f512h.h>
#include <p32xxxx.h>